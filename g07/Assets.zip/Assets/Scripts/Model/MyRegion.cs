using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MyRegion : MonoBehaviour
{
    public int num;//编号
    FirstSceneController sceneController;//场记    
    //标记玩家进入
    private void OnTriggerEnter(Collider other) {
        sceneController = SSDirector.GetInstance().CurrentSceneController as FirstSceneController;
        if (other.gameObject.tag == "Player") {
            sceneController.playerRegion = num;
        }    
    }
    //巡逻兵在自己的区域
    private void OnTriggerExit(Collider other) {
        if (other.gameObject.tag == "Patrol") {
            
            other.gameObject.GetComponent<Patrol>().isCollided = true;
        }
    }
    
}
