using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Patrol : MonoBehaviour
{
    public int patrolRegion;//巡逻兵所在区域
    public bool isFollowing;//是否追捕玩家
    public GameObject player;//玩家 
    public bool isPlayerInRange;//玩家是否在侦擦范围    
    public bool isCollided;//是否碰撞         
    public int playerRegion;//玩家所在区域           
}
