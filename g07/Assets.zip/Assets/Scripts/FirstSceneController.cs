using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class FirstSceneController : MonoBehaviour, SceneController, UserAction
{
    public int playerRegion;//玩家所在的区域  
    public PatrolActionManager patrolActionManager;
    public PatrolFactory patrolFactory;
    public UserGUI userGUI;
    public ScoreRecorder scoreRecorder;
    public GameObject player;
    private GameState gameState = GameState.START;
    private List<GameObject> patrols;
    // Start is called before the first frame update
    void Start() {
        SSDirector director = SSDirector.GetInstance();
        director.CurrentSceneController = this;
        scoreRecorder = Singleton<ScoreRecorder>.Instance;
        patrolFactory = Singleton<PatrolFactory>.Instance;
        playerRegion = 5;
        patrolActionManager = gameObject.AddComponent<PatrolActionManager>();
        userGUI = gameObject.AddComponent<UserGUI>() as UserGUI;
        director.SetFPS(30);
        director.leftSeconds = 60;
        LoadResources();
        //巡逻兵开始巡逻
        for (int i = 0; i < patrols.Count; i++) {
            patrolActionManager.Patrol(patrols[i]);
        }
    }

    public void LoadResources() {
        Instantiate(Resources.Load<GameObject>("Prefabs/Plane"));
        player = Instantiate(Resources.Load("Prefabs/Player"), new Vector3(-1.5f, 0, -1.5f), Quaternion.identity) as GameObject;
        patrols = patrolFactory.GetPatrols();
        Camera.main.GetComponent<CameraFollowAction>().player = player;
    }

    private void Update() {
        for (int i = 0; i < patrols.Count; i++) {
            // 更新玩家区域信息
            patrols[i].GetComponent<Patrol>().playerRegion = playerRegion;
        }
    }

    void OnEnable() {
        // 订阅游戏事件
        GameEventManager.OnGoalLost += OnGoalLost;
        GameEventManager.OnFollowing += OnFollowing;
        GameEventManager.GameOver += GameOver;
        GameEventManager.Win += Win;
    }

    void OnDisable() {
        GameEventManager.OnGoalLost -= OnGoalLost;
        GameEventManager.OnFollowing -= OnFollowing;
        GameEventManager.GameOver -= GameOver;
        GameEventManager.Win -= Win;
    }

    public void MovePlayer(float translationX, float translationZ) {
        if (translationX != 0 || translationZ != 0) {
            player.GetComponent<Animator>().SetBool("run", true);
        } else {
            player.GetComponent<Animator>().SetBool("run", false);
        }
        translationX *= Time.deltaTime;
        translationZ *= Time.deltaTime;
        
        player.transform.LookAt(new Vector3(player.transform.position.x + translationX, player.transform.position.y, player.transform.position.z + translationZ));
        if (translationX == 0)
            player.transform.Translate(0, 0, Mathf.Abs(translationZ) * 2);
        else if (translationZ == 0)
            player.transform.Translate(0, 0, Mathf.Abs(translationX) * 2);
        else
            player.transform.Translate(0, 0, Mathf.Abs(translationZ) + Mathf.Abs(translationX));
        ////////////////
        //锁定鼠标到屏幕中心
        // Cursor.lockState = CursorLockMode.Locked;
        // Cursor.lockState = CursorLockMode.None;
        // //隐藏鼠标
        // Cursor.visible = false;
 
        // //当前垂直角度
        // double VerticalAngle = Camera.main.transform.eulerAngles.x;
 
        // //通过鼠标获取竖直、水平轴的值，范围在-1到1
        // float h = Input.GetAxis("Mouse X");
        // float v = Input.GetAxis("Mouse Y") * -1;
 
        // //角色水平旋转
        // player.transform.Rotate(Vector3.up * h * Time.deltaTime * 135* 10*0.1f);
 
        // //计算本次旋转后，竖直方向上的欧拉角
        // double targetAngle = VerticalAngle + v * Time.deltaTime * 135 * 5;
 
        // //竖直方向视角限制
        // if (targetAngle > 90 && targetAngle < 360 - 25) ;
        // else
        // //摄像机竖直方向上旋转
        // Camera.main.transform.Rotate(Vector3.right * v * Time.deltaTime * 135 * 5*0.1f);

    }

    // 失去目标，巡逻兵放弃追击
    public void OnGoalLost(GameObject patrol) {
        patrolActionManager.Patrol(patrol);
        scoreRecorder.Record();
    }

    // 玩家进入范围，巡逻兵开始追击
    public void OnFollowing(GameObject patrol) {
        patrolActionManager.Follow(player, patrol);
    }

    // 失败
    public void GameOver() {
        gameState = GameState.LOSE;
        StopAllCoroutines();
        patrolFactory.PausePatrol();
        player.GetComponent<Animator>().SetTrigger("death");
        patrolActionManager.DestroyAllActions();
    }

    // 胜利
    public void Win() {
        gameState = GameState.WIN;
        StopAllCoroutines();
        patrolFactory.PausePatrol();
    }

    // 获取分数
    public int GetScore() {
        return scoreRecorder.score;
    }

    // 重新开始
    public void Restart() {
        SceneManager.LoadScene("Scenes/SampleScene");
    }

    // 暂停游戏
    public void Pause() {
        gameState = GameState.PAUSE;
        patrolFactory.PausePatrol();
        player.GetComponent<Animator>().SetBool("pause", true);
        StopAllCoroutines();
    }

    // 开始游戏
    public void Begin() {
        gameState = GameState.RUNNING;
        patrolFactory.StartPatrol();
        player.GetComponent<Animator>().SetBool("pause", false);
        StartCoroutine(SSDirector.GetInstance().CountDown());
    }

    // 获取游戏状态
    public GameState getGameState() {
        return gameState;
    }

    // 设置游戏状态
    public void setGameState(GameState gs) {
        gameState = gs;
    }
}
