using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SSDirector : System.Object
{
    private static SSDirector _instance;                          
    public SceneController CurrentSceneController { get; set; } 
    public int leftSeconds = 60;                               
    private SSDirector() {}
    public static SSDirector GetInstance() {
        if (_instance == null) {
            _instance = new SSDirector();
        }
        return _instance;
    }

    public int GetFPS() {
        return Application.targetFrameRate;
    }

    public void SetFPS(int fps) {
        Application.targetFrameRate = fps;
    }
    public IEnumerator CountDown() {
        while (leftSeconds > 0) {
            yield return new WaitForSeconds(1f);
            leftSeconds--;
            if (leftSeconds == 0) {
                Singleton<GameEventManager>.Instance.TimeIsUP();
            }
        }
    }
}
